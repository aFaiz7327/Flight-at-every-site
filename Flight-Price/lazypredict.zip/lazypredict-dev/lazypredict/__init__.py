# -*- coding: utf-8 -*-

"""Top-level package for Lazy Predict."""

__author__ = """Shankar Rao Pandala"""
__email__ = "shankar.pandala@live.com"
__version__ = '0.2.9'
